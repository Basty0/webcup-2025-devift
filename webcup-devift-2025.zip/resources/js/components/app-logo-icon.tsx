export default function AppLogoIcon({ ...props }) {
    return <img src="/logo.png" alt="TheEnd" className="h-10 w-10 rounded-full" {...props} />;
}
