<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\daoud\Desktop\project\PROJECT\LARAVEL\Laravel12\webcup-devift-2025\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>