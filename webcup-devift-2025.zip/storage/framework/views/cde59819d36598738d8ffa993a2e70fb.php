<?php echo e($slot); ?>

<?php /**PATH C:\Users\daoud\Desktop\project\PROJECT\LARAVEL\Laravel12\webcup-devift-2025\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>