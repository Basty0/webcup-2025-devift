<?php echo e($slot); ?>

<?php /**PATH C:\Users\daoud\Desktop\project\PROJECT\LARAVEL\Laravel12\webcup-devift-2025\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>